---
name: Obsidian Command
colors:
  surface: '#131316'
  surface-dim: '#131316'
  surface-bright: '#39393c'
  surface-container-lowest: '#0e0e11'
  surface-container-low: '#1c1b1e'
  surface-container: '#201f22'
  surface-container-high: '#2a2a2d'
  surface-container-highest: '#353438'
  on-surface: '#e5e1e5'
  on-surface-variant: '#bbc9cd'
  inverse-surface: '#e5e1e5'
  inverse-on-surface: '#313033'
  outline: '#859397'
  outline-variant: '#3c494c'
  surface-tint: '#2fd9f4'
  primary: '#8aebff'
  on-primary: '#00363e'
  primary-container: '#22d3ee'
  on-primary-container: '#005763'
  inverse-primary: '#006877'
  secondary: '#4edea3'
  on-secondary: '#003824'
  secondary-container: '#00a572'
  on-secondary-container: '#00311f'
  tertiary: '#c8e88d'
  on-tertiary: '#243600'
  tertiary-container: '#adcb74'
  on-tertiary-container: '#3e560b'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#a2eeff'
  primary-fixed-dim: '#2fd9f4'
  on-primary-fixed: '#001f25'
  on-primary-fixed-variant: '#004e5a'
  secondary-fixed: '#6ffbbe'
  secondary-fixed-dim: '#4edea3'
  on-secondary-fixed: '#002113'
  on-secondary-fixed-variant: '#005236'
  tertiary-fixed: '#ceee93'
  tertiary-fixed-dim: '#b3d17a'
  on-tertiary-fixed: '#131f00'
  on-tertiary-fixed-variant: '#364e03'
  background: '#131316'
  on-background: '#e5e1e5'
  surface-variant: '#353438'
typography:
  display-lg:
    fontFamily: Geist
    fontSize: 40px
    fontWeight: '600'
    lineHeight: 48px
    letterSpacing: -0.03em
  headline-lg:
    fontFamily: Geist
    fontSize: 30px
    fontWeight: '600'
    lineHeight: 36px
    letterSpacing: -0.025em
  headline-lg-mobile:
    fontFamily: Geist
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Geist
    fontSize: 20px
    fontWeight: '500'
    lineHeight: 28px
    letterSpacing: -0.02em
  title-sm:
    fontFamily: Geist
    fontSize: 16px
    fontWeight: '500'
    lineHeight: 24px
    letterSpacing: -0.015em
  body-md:
    fontFamily: Geist
    fontSize: 14px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: -0.01em
  body-sm:
    fontFamily: Geist
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 18px
    letterSpacing: -0.005em
  label-mono-md:
    fontFamily: JetBrains Mono
    fontSize: 13px
    fontWeight: '500'
    lineHeight: 16px
    letterSpacing: -0.01em
  label-mono-sm:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '500'
    lineHeight: 14px
    letterSpacing: 0.02em
  label-mono-xs:
    fontFamily: JetBrains Mono
    fontSize: 10px
    fontWeight: '500'
    lineHeight: 12px
    letterSpacing: 0.04em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1rem
  gutter-desktop: 1.25rem
  margin: 1rem
  margin-desktop: 2rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 0.75rem
  space-lg: 1.25rem
  space-xl: 2rem
---

## Brand & Style

This design system embodies high-density, mission-critical engineering precision. Inspired by top-tier developer platforms and technical orchestrators, it creates an environment of absolute control, razor-sharp focus, and technical elegance. 

### Aesthetic Pillars
- **Surgical Minimalism:** Interfaces strip away all decorative chrome, prioritizing information architecture, dense telemetry, and rapid key commands. Every pixel functions with calculated intent.
- **Obsidian Dark Architecture:** Deep, light-absorbing bases paired with subtly stepped, cold-tinted dark bento panels create optical hierarchy without distracting high-contrast shifts.
- **Micro-Precision Accents:** Vivid functional accents—cyan, emerald, and electric lime—are deployed strictly as telemetry indicators, execution confirmations, and active states, never as decorative fills.
- **Technical Monospace Calibration:** Clear split between crisp sans-serif display typography and structured tabular monospace labels, reinforcing a CLI-grade mental model.

## Colors

The color palette is engineered for prolonged operational focus in ultra-dark environments, balancing high-contrast readability against ocular fatigue.

### Surface Tiers
- **Canvas Base (`#050507`):** Pitch obsidian void, grounding the root application canvas.
- **Surface Level 1 (`#0A0B0F`):** Primary bento modules, navigation sidebars, and structural groupings.
- **Surface Level 2 (`#0E1015`):** Interactive inputs, nested cards, dropdown overlays, and hovering nodes.
- **Surface Highlight (`#E0F2FE`):** Polar ice tint reserved exclusively for ultra-high-priority state markers, active spotlight backdrops, and active badge fills at 8–12% opacity.

### Hairline Infrastructure
- **Borders & Dividers:** `rgba(255, 255, 255, 0.08)` for uniform hairline bounding.
- **Subtle Interactive Border:** `rgba(255, 255, 255, 0.16)` on hover/focus.
- **Active Structural Ring:** `rgba(34, 211, 238, 0.35)` for focused states and operational active boundaries.

### Typographic Contrast Scale
- **Primary Text (`#F8FAFC`):** Crisp, untinted high-contrast text for critical metrics and primary data.
- **Secondary Slate (`#94A3B8`):** Balanced mid-tier copy, supporting descriptions, and structural labels.
- **Muted Technical Slate (`#64748B`):** Monospace metrics, timestamps, inactive states, and keyboard shortcut glyphs.

### Functional Accents
- **Cyan (`#22D3EE`):** Primary routing, primary actions, active telemetry streams, and cursor selections.
- **Emerald (`#10B981`):** Operational health, successful builds, verified states, and optimal latency metrics.
- **Electric Lime (`#D9F99D`):** Real-time warnings, high-voltage indicators, pending tasks, and live changes.

## Typography

The typography couples the Swiss-inspired, high-density neutral sans **Geist** with the tabular rigor of **JetBrains Mono**.

### Structural Application Rules
- **Display & Headings:** Rendered with tight tracking (`-0.02em` to `-0.03em`) and medium/semibold weights to ensure dense horizontal scanning without optical vibration.
- **Monospace Deployment:** `JetBrains Mono` is enforced for status tags, keyboard shortcuts (`kbd`), commit SHAs, latency numbers, and table cell data. Always activate `font-variant-numeric: tabular-nums` to eliminate jitter during real-time updates.
- **Micro-Labels:** Use uppercase tracking on `label-mono-xs` exclusively for categorized table headers, metric tags, and system states.

## Layout & Spacing

The layout is built around dense bento-grid modules, utilizing strict horizontal and vertical alignment lines to simulate instrument clusters.

### Bento Grid Configuration
- **Desktop (≥ 1280px):** 12-column or 16-column continuous fluid layout bounded by `margin-desktop` (2rem). Gutters lock at `1.25rem`. Layout components span modular 4-, 8-, and 12-unit partitions.
- **Tablet (768px - 1279px):** 8-column layout with `1rem` gutters. Complex multi-tier telemetry collapses into two vertical column blocks.
- **Mobile (< 768px):** Single-column stacked stream. Sidebars convert to slide-over command sheets. Gutters drop to `0.75rem`.

### Spacing Philosophy
- Interfaces prioritize compact functional density (`space-xs` and `space-sm` for control groupings) over decorative whitespace.
- Bento cards employ internal padding of `space-md` (0.75rem) to `space-lg` (1.25rem) to maximize data yield without sacrificing hairline visual boundaries.

## Elevation & Depth

This design system avoids blurry drop-shadows and heavy atmospheric skeuomorphism in favor of structural hairline boundaries and micro-luminance stepping.

### Surface Hierarchy
1. **Floor 0 (Canvas):** `#050507` baseline.
2. **Floor 1 (Bento Paneling):** `#0A0B0F` with an unbroken border of `1px solid rgba(255, 255, 255, 0.08)`.
3. **Floor 2 (Floating Overlays / Modals / Menus):** `#0E1015` with a `1px solid rgba(255, 255, 255, 0.14)` border and an ambient structural shadow: `0 8px 32px -4px rgba(0, 0, 0, 0.75)`.

### Surgical Edge Illumination
- Interactive elements (cards, command inputs) utilize subtle inset edge highlights: `box-shadow: inset 0 1px 0 0 rgba(255, 255, 255, 0.05)`.
- Active states deploy cyan edge diffusion: `box-shadow: 0 0 0 1px rgba(34, 211, 238, 0.4), 0 0 12px -2px rgba(34, 211, 238, 0.2)`.

## Shapes

The design system enforces a soft, mechanical corner radius (Level 1: `4px` base) that delivers precision-engineered edges without harsh 90-degree brutality.

### Geometry Specifications
- **Controls & Micro-Chips:** `4px` (`0.25rem`). Buttons, inputs, search triggers, and status tags remain razor-crisp.
- **Bento Modules & Containers:** `8px` (`0.5rem`). Standard containers, panels, and floating popovers.
- **Large Contextual Overlays:** `12px` (`0.75rem`). Full-screen command palettes and central modals.
- **Status Beads:** Fully circular (`rounded-full`) 6px indicators used for telemetry pinging.

## Components

### Buttons
- **Primary:** Background `#22D3EE`, text `#050507`, font weight `500`. Hover state triggers opacity shift to `90%` and cyan edge luminescence.
- **Secondary (Default):** Background `#0E1015`, text `#F8FAFC`, border `1px solid rgba(255, 255, 255, 0.08)`. Hover transitions border to `rgba(255, 255, 255, 0.18)` with subtle background shift to `#141720`.
- **Ghost / Tooling:** Background transparent, text `#94A3B8`. Hover text `#F8FAFC` and background `rgba(255, 255, 255, 0.04)`.
- **Keyboard Indicator (`kbd`):** Nested monospace micro-badges within buttons: background `#050507`, border `1px solid rgba(255, 255, 255, 0.12)`, text `#64748B`, padding `1px 4px`.

### Command Palette & Inputs
- **Command Field:** Height `40px`, background `#0A0B0F`, border `1px solid rgba(255, 255, 255, 0.12)`, text `#F8FAFC`, placeholder `#64748B`. Focused state introduces a crisp `1px solid #22D3EE` border without oversized soft focus rings.
- **Dense Input:** Height `32px`, font size `13px`, JetBrains Mono padding for code/variable entry.

### Bento Metric & Highlight Cards
- **Base Card:** Background `#0A0B0F`, `1px solid rgba(255, 255, 255, 0.08)`. Internal header row displays a muted label (`#64748B`) alongside a micro-badge.
- **Ice Blue Highlight Card:** Background `rgba(224, 242, 254, 0.03)`, border `1px solid rgba(224, 242, 254, 0.2)`. Houses critical active deployments or highlighted real-time outputs.

### Status Indicators & Chips
- **Telemetry Chips:** Compact pill/rectangular badges (height `20px`), background `rgba(255, 255, 255, 0.03)`, border `1px solid rgba(255, 255, 255, 0.08)`, font `JetBrains Mono` 11px.
- **State Beads:** 6px circular nodes with matching radial glow:
  - **Healthy:** `#10B981` with `box-shadow: 0 0 6px rgba(16, 185, 129, 0.5)`.
  - **Warning/Syncing:** `#D9F99D` with `box-shadow: 0 0 6px rgba(217, 249, 157, 0.5)`.
  - **Active Stream:** `#22D3EE` with `box-shadow: 0 0 6px rgba(34, 211, 238, 0.5)`.

### Lists & Data Tables
- Row height `36px` to `40px` for high information density.
- Separated by `1px solid rgba(255, 255, 255, 0.04)`.
- Row hover triggers immediate `rgba(255, 255, 255, 0.02)` background tint with active cell text snapping to `#F8FAFC`.
- All timestamps, IDs, and numeric readings aligned to the right using `JetBrains Mono`.

### Checkboxes & Toggle Switches
- **Checkbox:** `14px` by `14px`, border `1px solid rgba(255, 255, 255, 0.2)`, radius `2px`. Checked state fills `#22D3EE` with `#050507` checkmark.
- **Micro-Toggle:** Width `28px`, height `16px`. Inactive track `#0E1015`, active track `#10B981`. Thumb is a `12px` solid `#F8FAFC` circle.